# Stop_Watch
This is a hardware description for a digital stopwatch written in VHDL.
