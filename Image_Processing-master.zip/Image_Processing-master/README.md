## Image Processing 
This folder contains implementations of various image processing algorithms written in both VHDL and C++. 
These algorithms are designed to run on FPGA platforms and perform real-time image processing tasks.
