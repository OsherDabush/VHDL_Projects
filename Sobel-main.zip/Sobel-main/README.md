# Sobel
Sobel Filter Acceleration on FPGA with PYNQ and OpenCV
